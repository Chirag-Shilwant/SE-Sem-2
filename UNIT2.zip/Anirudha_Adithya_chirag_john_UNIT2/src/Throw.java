import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

import java.util.*;
import java.text.*;

public class Throw implements ActionListener{
	private JFrame win;
	private int emoticonId;
	private JButton yesButton;
	private int result;
	public Throw( ) {
		result =0;
		win = new JFrame("Emoticon");
		win.getContentPane().setLayout(new BorderLayout());
		((JPanel) win.getContentPane()).setOpaque(false);
		win.setSize(512,512);
		
		JPanel colPanel = new JPanel(); // Create a panel
		colPanel.setLayout(new GridLayout( 2, 1 )); // Sets out a grid layout with 2 rows and 1 panel (I presume)

		// Label Panel
		JPanel labelPanel = new JPanel();
		labelPanel.setLayout(new FlowLayout());
		
		JLabel message = new JLabel( "Press To BOWL" );

		labelPanel.add( message );

		// Button Panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1, 2));

		Insets buttonMargin = new Insets(4, 4, 4, 4);

		yesButton = new JButton("Yes");
		JPanel yesButtonPanel = new JPanel();
		yesButtonPanel.setLayout(new FlowLayout());
		yesButton.addActionListener(this);
		yesButtonPanel.add(yesButton);
		buttonPanel.add(yesButton);
		colPanel.add(labelPanel);
		colPanel.add(buttonPanel);
		win.getContentPane().add("Center", colPanel);
		win.pack();


		Dimension screenSize = (Toolkit.getDefaultToolkit()).getScreenSize();
		win.setLocation(
			((screenSize.width) / 2) - ((win.getSize().width) / 2),
			((screenSize.height) / 2) - ((win.getSize().height) / 2));
		win.show();

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(yesButton)) {		
			result=1;
		}
	}

	public int getResult() {
		while ( result == 0 ) {
			try {
				Thread.sleep(10);
			} catch ( InterruptedException e ) {
				System.err.println( "Interrupted" );
			}
		}
		return result;	
	}

	public void destroy() {
		win.hide();
	}

}